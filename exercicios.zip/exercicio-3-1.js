function multiplicationTable(number) {
    for (let i = 1; i < 11; i++) {
        console.log(`${number} * ${i} = ${number * i}`);
    }
}
