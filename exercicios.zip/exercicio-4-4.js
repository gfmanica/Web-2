const square = (number) => number * number;
