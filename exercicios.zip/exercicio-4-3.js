(function () {
    return (22 * 9) / 5 + 32;
})();
